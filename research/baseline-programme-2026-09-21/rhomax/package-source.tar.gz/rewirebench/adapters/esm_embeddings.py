"""Frozen ESM-2 8M mean-pooled representations for protocol-owned probes.

Pooling follows the official ESM representation example: final-layer residue
representations, excluding BOS/EOS and padding. No labels enter the encoder.
This is a new evaluated pipeline, not reproduction of a published model score.
"""
from __future__ import annotations

import hashlib
from pathlib import Path

from rewirebench.adapters.esm import ESM2Adapter
from rewirebench.protocols.proteingym import AMINO_ACIDS


class ESM2Embeddings:
    def __init__(self, checkpoint, *, device="cpu"):
        self.encoder = ESM2Adapter(checkpoint, device=device)
        self.provenance = {**self.encoder.provenance,
            "implementation_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            "strategy": "frozen_final_layer_residue_mean_excluding_special_tokens",
            "representation_layer": 6,
            "reference": "https://github.com/facebookresearch/esm#usage",
            "published_result_reproduction": False,
        }

    def embed(self, inputs):
        ids = [row.get("id") for row in inputs]
        if len(ids) != len(set(ids)) or any(not isinstance(x, str) or not x for x in ids):
            raise ValueError("Embedding inputs require unique nonempty IDs")
        for row in inputs:
            if set(row) != {"id", "sequence"}:
                raise ValueError("ESM embedding inputs allow only id and sequence, never labels")
            sequence = row["sequence"]
            if (not isinstance(sequence, str) or not 1 <= len(sequence) <= 1022
                    or set(sequence) - (AMINO_ACIDS | set("XBZUO"))):
                raise ValueError("ESM embeddings require 1..1022 valid amino-acid residues; no cropping")
        if not inputs:
            return {}
        encoder = self.encoder
        _, _, tokens = encoder.converter([(row["id"], row["sequence"]) for row in inputs])
        with encoder.torch.inference_mode():
            vectors = encoder.model(tokens.to(encoder.device), repr_layers=[6],
                                    return_contacts=False)["representations"][6]
        return {row["id"]: vectors[i, 1:len(row["sequence"]) + 1].mean(0).cpu().tolist()
                for i, row in enumerate(inputs)}
